from django.core.management.base import BaseCommand
from api.models import User

class Command(BaseCommand):
    help = 'Creates a default admin user'

    def handle(self, *args, **options):
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser(
                username='admin',
                password='admin123',
                email='admin@example.com',
                employee_id='ADMIN001',
                first_name='Admin',
                last_name='User',
                position='Administrator',
                role='Admin'
            )
            self.stdout.write(self.style.SUCCESS('Successfully created admin user'))
        else:
            self.stdout.write(self.style.SUCCESS('Admin user already exists')) 