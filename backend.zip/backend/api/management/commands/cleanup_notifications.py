from django.core.management.base import BaseCommand
from django.utils import timezone
from api.models import Notification, Product, Inventory
import logging

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Cleans up expired notifications and updates low stock status'

    def handle(self, *args, **options):
        try:
            from api.models import cleanup_expired_notifications
            expired_count, low_stock_count = cleanup_expired_notifications()
            
            self.stdout.write(
                self.style.SUCCESS(
                    f'Successfully cleaned up {expired_count} expired notifications and '
                    f'deactivated {low_stock_count} low stock notifications'
                )
            )
        except Exception as e:
            logger.error(f"Error in cleanup_notifications command: {str(e)}")
            self.stdout.write(
                self.style.ERROR(f'Error cleaning up notifications: {str(e)}')
            ) 