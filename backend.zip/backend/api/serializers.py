from rest_framework import serializers
from .models import Product, Inventory, Sale, Report, CustomUser, Notification
from django.utils import timezone
import logging
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

logger = logging.getLogger(__name__)

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        
        # Add custom claims
        token['role'] = user.role
        token['username'] = user.username
        token['employee_id'] = user.employee_id
        token['position'] = user.position
        
        return token

class ProductSerializer(serializers.ModelSerializer):
    quantity = serializers.IntegerField(default=0)
    selling_price = serializers.DecimalField(max_digits=10, decimal_places=2, default=0)
    expiration_date = serializers.DateField(allow_null=True)
    category = serializers.CharField(required=True)

    def validate_expiration_date(self, value):
        if value and value < timezone.now().date():
            logger.warning(f"Product with expiration date in the past: {value}")
            return value
        return value

    def validate_quantity(self, value):
        if value < 0:
            logger.warning(f"Product with negative quantity: {value}")
            return 0
        return value

    def validate_selling_price(self, value):
        if value < 0:
            logger.warning(f"Product with negative selling price: {value}")
            return 0
        return value

    class Meta:
        model = Product
        fields = ['id', 'name', 'brand', 'quantity', 'expiration_date', 'selling_price', 'category']
        extra_kwargs = {
            'name': {'required': True},
            'brand': {'required': True},
            'quantity': {'required': True},
            'selling_price': {'required': True},
            'category': {'required': True}
        }

class InventorySerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_brand = serializers.CharField(source='product.brand', read_only=True)
    product_expiration = serializers.DateField(source='product.expiration_date', read_only=True)
    product = ProductSerializer(read_only=True)
    product_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(),
        source='product',
        write_only=True
    )
    quantity = serializers.SerializerMethodField()
    selling_price = serializers.DecimalField(source='product.selling_price', read_only=True, max_digits=10, decimal_places=2)
    status = serializers.SerializerMethodField()
    expiration_date = serializers.DateField(source='product.expiration_date', read_only=True)
    reorder_level = serializers.IntegerField(default=10)

    def get_quantity(self, obj):
        try:
            return obj.product.quantity
        except:
            return 0

    def get_status(self, obj):
        if obj.product.quantity <= 0:
            return "Out of Stock"
        elif obj.product.quantity <= obj.reorder_level:
            return "Low Stock"
        return "In Stock"

    class Meta:
        model = Inventory
        fields = ['id', 'product', 'product_id', 'product_name', 'product_brand', 
                 'product_expiration', 'unit_price', 'reorder_level', 'date_of_receive',
                 'status', 'quantity', 'selling_price', 'expiration_date']

    def validate(self, data):
        try:
            product = data.get('product')
            if not product:
                raise serializers.ValidationError("Product is required")
            
            reorder_level = data.get('reorder_level', 10)
            if reorder_level < 0:
                raise serializers.ValidationError("Reorder level cannot be negative")
            
            return data
        except Exception as e:
            raise serializers.ValidationError(str(e))

    def create(self, validated_data):
        try:
            product = validated_data.pop('product')
            inventory = Inventory.objects.create(product=product, **validated_data)
            return inventory
        except Exception as e:
            raise serializers.ValidationError(str(e))

    def update(self, instance, validated_data):
        try:
            product = validated_data.pop('product', None)
            if product:
                instance.product = product
            
            for attr, value in validated_data.items():
                setattr(instance, attr, value)
            
            instance.save()
            return instance
        except Exception as e:
            raise serializers.ValidationError(str(e))

class SaleSerializer(serializers.ModelSerializer):
    product_details = ProductSerializer(source='product', read_only=True)
    
    class Meta:
        model = Sale
        fields = ['id', 'product', 'product_details', 'quantity', 'amount_paid', 'date_of_sale']

class ReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = [
            'id', 'username', 'email', 'password', 
            'first_name', 'last_name', 'is_staff', 'is_active',
            'employee_id', 'position', 'role', 'middle_name'
        ]
        extra_kwargs = {
            'password': {'write_only': True},
            'id': {'read_only': True},
        }

    def create(self, validated_data):
        try:
            user = CustomUser.objects.create_user(
                username=validated_data['username'],
                email=validated_data['email'],
                password=validated_data['password'],
                first_name=validated_data.get('first_name', ''),
                last_name=validated_data.get('last_name', ''),
                employee_id=validated_data.get('employee_id', ''),
                position=validated_data.get('position', ''),
                role=validated_data.get('role', 'Cashier/Pharmacist'),
                middle_name=validated_data.get('middle_name', ''),
                is_staff=validated_data.get('is_staff', False)
            )
            return user
        except Exception as e:
            logger.error(f"Error creating user: {str(e)}")
            raise serializers.ValidationError(str(e))

    def update(self, instance, validated_data):
        try:
            if 'password' in validated_data:
                instance.set_password(validated_data.pop('password'))
            
            for attr, value in validated_data.items():
                setattr(instance, attr, value)
            
            instance.save()
            return instance
        except Exception as e:
            logger.error(f"Error updating user: {str(e)}")
            raise serializers.ValidationError(str(e))

class NotificationSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    product_brand = serializers.CharField(source='product.brand', read_only=True)

    class Meta:
        model = Notification
        fields = ['id', 'type', 'message', 'created_at', 'expiry_date', 'is_active', 'product_name', 'product_brand']
        read_only_fields = ['type', 'message', 'created_at', 'expiry_date', 'product_name', 'product_brand']