from rest_framework.viewsets import ModelViewSet
from rest_framework.response import Response
from rest_framework import status
from .models import Product, Inventory, Sale, Report, CustomUser, Notification, cleanup_expired_notifications
from .serializers import (
    ProductSerializer, InventorySerializer, SaleSerializer, 
    ReportSerializer, UserSerializer, CustomTokenObtainPairSerializer,
    NotificationSerializer
)
import logging
from rest_framework import serializers
from django.utils import timezone
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework_simplejwt.views import TokenViewBase
from rest_framework_simplejwt.exceptions import TokenError, InvalidToken
from django.db import models
from .authentication import set_jwt_cookies, delete_jwt_cookies
from django.db.models import Sum
from collections import defaultdict

logger = logging.getLogger(__name__)

class CustomTokenObtainPairView(TokenViewBase):
    serializer_class = CustomTokenObtainPairSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        try:
            serializer.is_valid(raise_exception=True)
        except TokenError as e:
            raise InvalidToken(e.args[0])

        response = Response(serializer.validated_data, status=status.HTTP_200_OK)
        response = set_jwt_cookies(
            response,
            serializer.validated_data['access'],
            serializer.validated_data['refresh']
        )
        return response

class ProductViewSet(ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

    def validate_products(self):
        try:
            products = Product.objects.all()
            for product in products:
                serializer = self.get_serializer(product)
                serializer.is_valid(raise_exception=True)
            return True
        except Exception as e:
            logger.error(f"Product validation error: {str(e)}")
            return False

    def list(self, request, *args, **kwargs):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in ProductViewSet list: {str(e)}")
            return Response(
                {"error": f"An error occurred while fetching products: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def create(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            product = serializer.save()

            # Get or create inventory record
            inventory, created = Inventory.objects.get_or_create(
                product=product,
                defaults={
                    'unit_price': product.selling_price,
                    'reorder_level': 10,
                    'date_of_receive': timezone.now().date()
                }
            )

            # If inventory already existed, update it
            if not created:
                inventory.unit_price = product.selling_price
                inventory.save()

            # Cleanup notifications after product update
            cleanup_expired_notifications()

            # Return both product and inventory data
            response_data = {
                'product': serializer.data,
                'inventory': InventorySerializer(inventory).data
            }
            return Response(response_data, status=status.HTTP_201_CREATED)
        except serializers.ValidationError as e:
            logger.error(f"Validation error in ProductViewSet create: {str(e)}")
            return Response(
                {"error": str(e)},
                status=status.HTTP_400_BAD_REQUEST
            )
        except Exception as e:
            logger.error(f"Error in ProductViewSet create: {str(e)}")
            return Response(
                {"error": f"An error occurred while creating product: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class InventoryViewSet(ModelViewSet):
    queryset = Inventory.objects.all()
    serializer_class = InventorySerializer

    def list(self, request, *args, **kwargs):
        try:
            queryset = self.filter_queryset(self.get_queryset().select_related('product'))
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in InventoryViewSet list: {str(e)}")
            return Response(
                {"error": f"An error occurred while fetching inventory data: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def create(self, request, *args, **kwargs):
        try:
            product_id = request.data.get('product_id')
            if not product_id:
                return Response(
                    {"error": "Product ID is required"},
                    status=status.HTTP_400_BAD_REQUEST
                )

            try:
                product = Product.objects.get(id=product_id)
            except Product.DoesNotExist:
                return Response(
                    {"error": "Product not found"},
                    status=status.HTTP_404_NOT_FOUND
                )

            # Update or create inventory record
            inventory, created = Inventory.objects.get_or_create(
                product=product,
                defaults={
                    'unit_price': product.selling_price,
                    'reorder_level': request.data.get('reorder_level', 10),
                    'date_of_receive': timezone.now().date()
                }
            )

            if not created:
                inventory.unit_price = request.data.get('unit_price', product.selling_price)
                inventory.reorder_level = request.data.get('reorder_level', inventory.reorder_level)
                inventory.save()

            # If quantity is provided, update this inventory record's product quantity
            new_quantity = request.data.get('quantity')
            if new_quantity is not None:
                product.quantity = int(new_quantity)
                product.save()

            # Recalculate the parent Product's quantity as the sum of all inventory records for this product
            total_quantity = sum([
                inv.product.quantity for inv in Inventory.objects.filter(product=product)
            ])
            product.quantity = total_quantity
            product.save()

            serializer = self.get_serializer(inventory)
            # Cleanup notifications after inventory update
            cleanup_expired_notifications()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        except Exception as e:
            logger.error(f"Error in InventoryViewSet create: {str(e)}")
            return Response(
                {"error": f"An error occurred while creating/updating inventory item: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def update(self, request, *args, **kwargs):
        try:
            partial = kwargs.pop('partial', False)
            instance = self.get_object()
            serializer = self.get_serializer(instance, data=request.data, partial=partial)
            serializer.is_valid(raise_exception=True)
            self.perform_update(serializer)

            # After updating inventory, recalculate the parent Product's quantity
            product = instance.product
            total_quantity = sum([
                inv.product.quantity for inv in Inventory.objects.filter(product=product)
            ])
            product.quantity = total_quantity
            product.save()

            # Cleanup notifications after inventory update
            cleanup_expired_notifications()

            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in InventoryViewSet update: {str(e)}")
            return Response(
                {"error": f"An error occurred while updating inventory item: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class SaleViewSet(ModelViewSet):
    queryset = Sale.objects.all()
    serializer_class = SaleSerializer
    
    def create(self, request, *args, **kwargs):
        # Get the product and quantity from the request
        product_id = request.data.get('product')
        quantity = request.data.get('quantity')
        
        try:
            # Get the product
            product = Product.objects.get(id=product_id)
            
            # Check if there's enough stock
            if product.quantity < quantity:
                return Response(
                    {"error": f"Insufficient stock. Only {product.quantity} available."},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Create the sale
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.perform_create(serializer)
            
            # Update the product quantity
            product.quantity -= quantity
            product.save()
            
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        except Product.DoesNotExist:
            return Response(
                {"error": "Product not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {"error": str(e)},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class ReportViewSet(ModelViewSet):
    queryset = Report.objects.all()
    serializer_class = ReportSerializer

class UserViewSet(ModelViewSet):
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated, IsAdminUser]

    def list(self, request):
        try:
            users = self.get_queryset()
            serializer = self.get_serializer(users, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error fetching users: {str(e)}")
            return Response(
                {"error": "Failed to fetch users"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def create(self, request):
        try:
            serializer = self.get_serializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error(f"Error creating user: {str(e)}")
            return Response(
                {"error": "Failed to create user"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def update(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            serializer = self.get_serializer(instance, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logger.error(f"Error updating user: {str(e)}")
            return Response(
                {"error": "Failed to update user"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            if instance == request.user:
                return Response(
                    {"error": "Cannot delete your own account"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            instance.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            logger.error(f"Error deleting user: {str(e)}")
            return Response(
                {"error": "Failed to delete user"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class AlertsViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated]
    
    def list(self, request):
        try:
            cleanup_expired_notifications()
            # Group products by (name, brand, category) and sum their quantities
            product_groups = {}
            for product in Product.objects.all():
                key = (product.name, product.brand, product.category)
                if key not in product_groups:
                    product_groups[key] = {
                        'quantity': 0,
                        'reorder_level': None,
                        'product_ids': [],
                        'parent_product_id': None,
                        'name': product.name,
                        'brand': product.brand,
                        'category': product.category
                    }
                product_groups[key]['quantity'] += product.quantity
                product_groups[key]['product_ids'].append(product.id)
                if product.expiration_date is None:
                    product_groups[key]['parent_product_id'] = product.id
                if product_groups[key]['parent_product_id'] is None:
                    product_groups[key]['parent_product_id'] = product.id
                # Use the lowest reorder_level among all inventories for this group
                try:
                    inv = Inventory.objects.get(product=product)
                    if (product_groups[key]['reorder_level'] is None or
                            inv.reorder_level < product_groups[key]['reorder_level']):
                        product_groups[key]['reorder_level'] = inv.reorder_level
                except Inventory.DoesNotExist:
                    pass

            alerts = []
            alert_keys = set()
            # Add low stock alerts (grouped by variant)
            for key, group in product_groups.items():
                # Compute status using the same logic as inventory page
                if group['quantity'] <= 0:
                    status = 'Out of Stock'
                elif group['quantity'] <= group['reorder_level']:
                    status = 'Low Stock'
                else:
                    status = 'In Stock'
                # Only notify if status is exactly 'Low Stock'
                if status == 'Low Stock':
                    alert_key = f"low_stock_{group['parent_product_id']}"
                    alert_keys.add(alert_key)
                    alerts.append({
                        'type': 'low_stock',
                        'product_id': group['parent_product_id'],
                        'product_name': group['name'],
                        'current_quantity': group['quantity'],
                        'reorder_level': group['reorder_level'],
                        'message': f"Low stock alert: {group['name']} is low on stock."
                    })
            # Add expiry alerts (dynamic)
            near_expiry_products = Product.objects.filter(
                expiration_date__isnull=False,
                expiration_date__lte=timezone.now().date() + timezone.timedelta(days=30)
            )
            for product in near_expiry_products:
                days_until_expiry = (product.expiration_date - timezone.now().date()).days
                key = f"expiry_{product.id}"
                alert_keys.add(key)
                alerts.append({
                    'type': 'expiry',
                    'product_id': product.id,
                    'product_name': product.name,
                    'expiration_date': product.expiration_date,
                    'days_until_expiry': days_until_expiry,
                    'message': f'Expiry alert: {product.name} expires in {days_until_expiry} days'
                })
            # Add active DB notifications (persistent)
            active_notifications = Notification.objects.filter(is_active=True).select_related('product')
            for notif in active_notifications:
                key = f"{notif.type}_{notif.product.id}"
                if key not in alert_keys:
                    alerts.append({
                        'type': notif.type,
                        'product_id': notif.product.id,
                        'product_name': notif.product.name,
                        'message': notif.message,
                        'created_at': notif.created_at,
                        'expiry_date': notif.expiry_date,
                    })
            return Response(alerts)
        except Exception as e:
            logger.error(f"Error fetching alerts: {str(e)}")
            return Response(
                {"error": "Failed to fetch alerts"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

class NotificationViewSet(ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = NotificationSerializer

    def get_queryset(self):
        return Notification.objects.filter(is_active=True).select_related('product')

    def list(self, request):
        try:
            queryset = self.get_queryset()
            serializer = self.get_serializer(queryset, many=True)
            return Response(serializer.data)
        except Exception as e:
            logger.error(f"Error in NotificationViewSet list: {str(e)}")
            return Response(
                {"error": f"An error occurred while fetching notifications: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def update(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            instance.is_active = False
            instance.save()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            logger.error(f"Error in NotificationViewSet update: {str(e)}")
            return Response(
                {"error": f"An error occurred while updating notification: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )