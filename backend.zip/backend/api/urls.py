from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ProductViewSet, InventoryViewSet, SaleViewSet, 
    ReportViewSet, UserViewSet, CustomTokenObtainPairView,
    AlertsViewSet
)
from rest_framework_simplejwt.views import TokenRefreshView

router = DefaultRouter()
router.register(r'products', ProductViewSet, basename='product')
router.register(r'inventory', InventoryViewSet, basename='inventory')
router.register(r'sales', SaleViewSet, basename='sales')
router.register(r'reports', ReportViewSet, basename='report')
router.register(r'users', UserViewSet, basename='user')
router.register(r'alerts', AlertsViewSet, basename='alerts')

urlpatterns = [
    path('', include(router.urls)),
    path('token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]