from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
from django.db.models.signals import post_save
from django.dispatch import receiver
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class CustomUser(AbstractUser):
    employee_id = models.CharField(max_length=50, unique=True)
    position = models.CharField(max_length=100)
    role = models.CharField(max_length=50, default='Cashier/Pharmacist')
    middle_name = models.CharField(max_length=50, blank=True, null=True)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email', 'employee_id', 'position', 'role']

    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.employee_id})"

class Product(models.Model):
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(default=0)
    brand = models.CharField(max_length=255)
    category = models.CharField(max_length=255, default='General')
    expiration_date = models.DateField(null=True, blank=True)
    selling_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.name} ({self.brand})"

class Inventory(models.Model):
    product = models.OneToOneField(Product, on_delete=models.CASCADE, related_name='inventory')
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    reorder_level = models.IntegerField(default=10)
    date_of_receive = models.DateField(default=timezone.now)

    def __str__(self):
        return f"Inventory for {self.product.name}"

class Sale(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2)
    date_of_sale = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Sale of {self.quantity} {self.product.name}"

class Report(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.title

class Notification(models.Model):
    NOTIFICATION_TYPES = (
        ('expiry', 'Expiry'),
        ('low_stock', 'Low Stock'),
    )
    
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='notifications')
    type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    message = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)
    expiry_date = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.type} notification for {self.product.name}"

    def check_expiry(self):
        if self.expiry_date and timezone.now() >= self.expiry_date:
            self.is_active = False
            self.save()

@receiver(post_save, sender=Product)
def create_or_update_inventory(sender, instance, created, **kwargs):
    try:
        inventory, created = Inventory.objects.get_or_create(
            product=instance,
            defaults={
                'unit_price': instance.selling_price or 0,
                'reorder_level': 10,  # Default reorder level
                'date_of_receive': timezone.now().date()
            }
        )
        if not created:
            inventory.unit_price = instance.selling_price or 0
            inventory.save()
    except Exception as e:
        logger.error(f"Error creating/updating inventory for product {instance.id}: {str(e)}")
        raise  # Re-raise the exception to ensure the transaction is rolled back

@receiver(post_save, sender=Inventory)
def update_inventory_on_reorder_change(sender, instance, **kwargs):
    try:
        instance.update_status()
    except Exception as e:
        logger.error(f"Error updating inventory status on reorder change: {str(e)}")

@receiver(post_save, sender=Product)
def create_product_notifications(sender, instance, created, **kwargs):
    try:
        # Check for expiry notification
        if instance.expiration_date:
            # Convert date to datetime at midnight
            expiry_datetime = timezone.make_aware(
                datetime.combine(instance.expiration_date, datetime.min.time())
            )
            # Only create notification if expiry is within 30 days
            if expiry_datetime > timezone.now() and expiry_datetime <= timezone.now() + timedelta(days=30):
                # Delete any existing expiry notifications for this product
                Notification.objects.filter(
                    product=instance,
                    type='expiry',
                    is_active=True
                ).delete()
                
                Notification.objects.create(
                    product=instance,
                    type='expiry',
                    message=f"{instance.name} will expire on {instance.expiration_date}",
                    expiry_date=expiry_datetime
                )

        # Always fetch the latest inventory for this product
        try:
            inventory = Inventory.objects.get(product=instance)
        except Inventory.DoesNotExist:
            inventory = None

        if inventory:
            if instance.quantity <= inventory.reorder_level:
                # Delete any existing low stock notifications for this product
                Notification.objects.filter(
                    product=instance,
                    type='low_stock',
                    is_active=True
                ).delete()
                
                Notification.objects.create(
                    product=instance,
                    type='low_stock',
                    message=f"{instance.name} is running low on stock. Current quantity: {instance.quantity}",
                    expiry_date=None
                )
            else:
                # If stock is now above reorder level, deactivate any active low stock notifications
                Notification.objects.filter(
                    product=instance,
                    type='low_stock',
                    is_active=True
                ).update(is_active=False)
    except Exception as e:
        logger.error(f"Error creating notifications for product {instance.id}: {str(e)}")

def cleanup_expired_notifications():
    try:
        # Deactivate expired notifications
        expired_notifications = Notification.objects.filter(
            expiry_date__lte=timezone.now(),
            is_active=True
        )
        expired_count = expired_notifications.count()
        expired_notifications.update(is_active=False)
        
        # Deactivate low stock notifications for products that are no longer low in stock
        low_stock_notifications = Notification.objects.filter(
            type='low_stock',
            is_active=True
        ).select_related('product', 'product__inventory')
        
        low_stock_count = 0
        for notification in low_stock_notifications:
            if notification.product.quantity > notification.product.inventory.reorder_level:
                notification.is_active = False
                notification.save()
                low_stock_count += 1
        
        logger.info(f"Cleaned up {expired_count} expired notifications and {low_stock_count} low stock notifications")
        return expired_count, low_stock_count
    except Exception as e:
        logger.error(f"Error in cleanup_expired_notifications: {str(e)}")
        return 0, 0

# Add periodic task to clean up expired notifications
from django.core.management.base import BaseCommand
from django.utils import timezone

# Add this to your Django management commands or use Celery for periodic tasks