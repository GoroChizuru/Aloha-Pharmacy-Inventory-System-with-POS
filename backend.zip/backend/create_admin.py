import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

from api.models import User

if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser(
        username='admin',
        password='admin123',
        email='admin@example.com',
        employee_id='ADMIN001',
        first_name='Admin',
        last_name='User',
        position='Administrator',
        role='Admin'
    )
    print('Successfully created admin user')
else:
    print('Admin user already exists') 