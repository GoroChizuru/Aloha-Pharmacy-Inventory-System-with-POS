import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom";
import Login from "./components/Login";
import ProductManagement from "./components/ProductManagement";
import InventoryManagement from "./components/InventoryManagement";
import POS from "./components/POS";
import Reports from "./components/Reports";
import Navbar from "./components/Navbar";
import { ProductProvider } from "./context/ProductContext";
import { InventoryProvider } from "./context/InventoryContext";
import { POSProvider } from "./context/POSContext";
import { AuthProvider, useAuth } from "./context/AuthContext";
import UserManagement from "./components/UserManagement";

const PrivateRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? children : <Navigate to="/login" />;
};

const PublicRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return !isAuthenticated ? children : <Navigate to="/products" />;
};

const App = () => {
  return (
    <Router>
      <AuthProvider>
        <ProductProvider>
          <InventoryProvider>
            <POSProvider>
              <Routes>
                <Route
                  path="/login"
                  element={
                    <PublicRoute>
                      <Login />
                    </PublicRoute>
                  }
                />
                <Route
                  path="/products"
                  element={
                    <PrivateRoute>
                      <Navbar>
                        <ProductManagement />
                      </Navbar>
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/inventory"
                  element={
                    <PrivateRoute>
                      <Navbar>
                        <InventoryManagement />
                      </Navbar>
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/pos"
                  element={
                    <PrivateRoute>
                      <Navbar>
                        <POS />
                      </Navbar>
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/reports"
                  element={
                    <PrivateRoute>
                      <Navbar>
                        <Reports />
                      </Navbar>
                    </PrivateRoute>
                  }
                />
                <Route
                  path="/users"
                  element={
                    <PrivateRoute>
                      <Navbar>
                        <UserManagement />
                      </Navbar>
                    </PrivateRoute>
                  }
                />
                <Route path="/" element={<Navigate to="/login" />} />
              </Routes>
            </POSProvider>
          </InventoryProvider>
        </ProductProvider>
      </AuthProvider>
    </Router>
  );
};

export default App;
