// Custom events for triggering refreshes across components
export const REFRESH_EVENTS = {
  PRODUCTS: "refreshProducts",
  INVENTORY: "refreshInventory",
  SALES: "refreshSales",
  ALL: "refreshAll",
};

// Function to trigger a refresh event
export const triggerRefresh = (eventType = REFRESH_EVENTS.ALL) => {
  window.dispatchEvent(new Event(eventType));
};

// Function to listen for refresh events
export const onRefresh = (eventType, callback) => {
  const handler = () => callback();
  window.addEventListener(eventType, handler);
  return () => window.removeEventListener(eventType, handler);
};
