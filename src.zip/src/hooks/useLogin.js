import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { api } from "../api";
import { jwtDecode } from "jwt-decode";

export const useLogin = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const response = await api.post("token/", formData);
      const { access, refresh } = response.data;

      if (access && refresh) {
        // Decode the JWT token to get user information
        const decodedToken = jwtDecode(access);
        const userRole = decodedToken.role || "Cashier/Pharmacist";

        // Store tokens and role in context
        login(access, refresh, userRole);

        // Navigate to products page
        navigate("/products");
      } else {
        setError("Invalid response from server - missing tokens");
      }
    } catch (error) {
      console.error("Login error:", error.response || error);
      if (error.response?.data) {
        setError(
          error.response.data.detail ||
            error.response.data.error ||
            "Invalid username or password"
        );
      } else {
        setError("An error occurred during login. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return {
    formData,
    error,
    isLoading,
    handleChange,
    handleSubmit,
  };
};
