import { useState, useEffect } from "react";
import { api } from "../api";
import React from "react";

export const useReports = () => {
  const [salesData, setSalesData] = useState([]);
  const [filteredSalesData, setFilteredSalesData] = useState([]);
  const [inventoryData, setInventoryData] = useState([]);
  const [dateRange, setDateRange] = useState({
    start: "",
    end: "",
  });
  const [totalSales, setTotalSales] = useState(0);
  const [lowStockItems, setLowStockItems] = useState([]);
  const [error, setError] = useState(null);

  const groupInventory = (items) => {
    const grouped = {};

    items.forEach((item) => {
      const key = `${item.product_name}_${item.product_brand}`;

      if (!grouped[key]) {
        grouped[key] = {
          id: item.product.id,
          name: item.product_name,
          brand: item.product_brand,
          totalStock: 0,
          minPrice: Infinity,
          maxPrice: -Infinity,
          variations: [],
          reorder_level: item.reorder_level || 10,
          status: "In Stock",
        };
      }

      grouped[key].variations.push(item);
      grouped[key].totalStock += parseInt(item.quantity || 0);
      grouped[key].minPrice = Math.min(
        grouped[key].minPrice,
        parseFloat(item.unit_price || 0)
      );
      grouped[key].maxPrice = Math.max(
        grouped[key].maxPrice,
        parseFloat(item.unit_price || 0)
      );

      // Update status based on total stock and reorder level
      if (grouped[key].totalStock <= 0) {
        grouped[key].status = "Out of Stock";
      } else if (grouped[key].totalStock <= grouped[key].reorder_level) {
        grouped[key].status = "Low Stock";
      } else {
        grouped[key].status = "In Stock";
      }
    });

    return Object.values(grouped);
  };

  const fetchData = async () => {
    try {
      const [salesResponse, inventoryResponse] = await Promise.all([
        api.get("sales/"),
        api.get("inventory/"),
      ]);

      // Process sales data to include product details
      const salesWithProducts = salesResponse.data.map((sale) => ({
        ...sale,
        total: parseFloat(sale.amount_paid || 0),
        product_name: sale.product_details?.name || "Unknown Product",
        product_brand: sale.product_details?.brand || "Generic",
      }));

      setSalesData(salesWithProducts);
      setFilteredSalesData(salesWithProducts);

      // Calculate total sales
      const total = salesWithProducts.reduce(
        (sum, sale) => sum + (sale.total || 0),
        0
      );
      setTotalSales(total);

      // Process inventory data
      const inventoryWithProducts = inventoryResponse.data;
      const groupedInventory = groupInventory(inventoryWithProducts);
      setInventoryData(groupedInventory);

      // Update low stock items
      const lowStock = groupedInventory.filter((item) => {
        return item.status === "Low Stock";
      });
      setLowStockItems(lowStock);
    } catch (error) {
      console.error("Error fetching data:", error);
      setError("Failed to fetch report data. Please try again.");
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Add effect to filter sales data when date range changes
  useEffect(() => {
    if (dateRange.start && dateRange.end) {
      const startDate = new Date(dateRange.start);
      const endDate = new Date(dateRange.end);
      endDate.setHours(23, 59, 59, 999); // Include the entire end date

      const filtered = salesData.filter((sale) => {
        const saleDate = new Date(sale.date_of_sale);
        return saleDate >= startDate && saleDate <= endDate;
      });
      setFilteredSalesData(filtered);
    } else {
      setFilteredSalesData([]); // Show no data if no date range selected
    }
  }, [dateRange, salesData]);

  // Filter inventory data by date range (if needed)
  const filteredInventoryData = React.useMemo(() => {
    if (dateRange.start && dateRange.end) {
      // If you want to filter inventory by a date field, add logic here
      // For now, just return all inventoryData
      return inventoryData;
    }
    return [];
  }, [dateRange, inventoryData]);

  const calculateTotalSales = () => {
    return filteredSalesData.reduce((acc, sale) => acc + (sale.total || 0), 0);
  };

  const calculateLowStockItems = () => {
    return inventoryData.filter((item) => item.status === "Low Stock").length;
  };

  const formatDate = (dateString) => {
    if (!dateString) return "-";
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (error) {
      return "-";
    }
  };

  const formatPrice = (price) => {
    const numericPrice = Number(price) || 0;
    return numericPrice.toFixed(2);
  };

  return {
    salesData: filteredSalesData,
    inventoryData: filteredInventoryData,
    dateRange,
    setDateRange,
    totalSales,
    lowStockItems,
    error,
    calculateTotalSales,
    calculateLowStockItems,
    formatDate,
    formatPrice,
    fetchData,
  };
};
