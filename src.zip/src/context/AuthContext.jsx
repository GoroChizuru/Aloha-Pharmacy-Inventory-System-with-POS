import React, { createContext, useContext, useState, useEffect } from "react";
import { api, setAuthToken } from "../api";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [tokens, setTokens] = useState(() => {
    const storedTokens = localStorage.getItem("tokens");
    return storedTokens
      ? JSON.parse(storedTokens)
      : { access: null, refresh: null };
  });
  const [userRole, setUserRole] = useState(() => {
    return localStorage.getItem("userRole") || null;
  });

  useEffect(() => {
    if (tokens.access) {
      localStorage.setItem("tokens", JSON.stringify(tokens));
      setAuthToken(tokens.access);
    } else {
      localStorage.removeItem("tokens");
      setAuthToken(null);
    }
  }, [tokens]);

  useEffect(() => {
    if (userRole) {
      localStorage.setItem("userRole", userRole);
    } else {
      localStorage.removeItem("userRole");
    }
  }, [userRole]);

  const login = (accessToken, refreshToken, role) => {
    setTokens({
      access: accessToken,
      refresh: refreshToken,
    });
    setUserRole(role);
  };

  const logout = () => {
    setTokens({
      access: null,
      refresh: null,
    });
    setUserRole(null);
    localStorage.removeItem("tokens");
    localStorage.removeItem("userRole");
  };

  const isAdmin = () => userRole === "Admin";
  const isPharmacist = () => userRole === "Cashier/Pharmacist";

  const value = {
    tokens,
    userRole,
    login,
    logout,
    isAuthenticated: !!tokens.access,
    isAdmin,
    isPharmacist,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
