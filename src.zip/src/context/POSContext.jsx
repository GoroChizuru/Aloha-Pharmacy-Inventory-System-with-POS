import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import { api } from "../api";
import { triggerRefresh, REFRESH_EVENTS } from "../utils/refreshEvents";

const POSContext = createContext();

export const POSProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [inventory, setInventory] = useState([]);

  const formatPrice = (price) => {
    return Number(price).toFixed(2);
  };

  const fetchInventory = useCallback(async () => {
    try {
      const response = await api.get("inventory/");
      setInventory(response.data);
    } catch (error) {
      console.error("Error fetching inventory:", error);
    }
  }, []);

  const groupProducts = useCallback((products) => {
    const grouped = {};

    products.forEach((product) => {
      const key = `${product.name}_${product.brand}`;
      if (!grouped[key]) {
        grouped[key] = {
          ...product,
          variations: [],
          totalQuantity: 0,
        };
      }
      grouped[key].variations.push(product);
      grouped[key].totalQuantity += parseInt(product.quantity || 0);

      // Sort variations by expiration date
      grouped[key].variations.sort((a, b) => {
        const dateA = new Date(a.expiration_date);
        const dateB = new Date(b.expiration_date);
        return dateA - dateB;
      });
    });

    return Object.values(grouped);
  }, []);

  const fetchProducts = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.get("/products/");
      const groupedProducts = groupProducts(response.data);
      setProducts(groupedProducts);
      await fetchInventory();
      setError(null);
    } catch (err) {
      setError("Failed to fetch products");
      console.error("Error fetching products:", err);
    } finally {
      setLoading(false);
    }
  }, [groupProducts, fetchInventory]);

  // Initial data fetch
  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Listen for refresh events
  useEffect(() => {
    const handleRefresh = () => {
      fetchProducts();
    };

    window.addEventListener(REFRESH_EVENTS.ALL, handleRefresh);
    return () => {
      window.removeEventListener(REFRESH_EVENTS.ALL, handleRefresh);
    };
  }, [fetchProducts]);

  const getStockLevel = useCallback((product) => {
    return product.totalQuantity || 0;
  }, []);

  const getNextExpiringProduct = useCallback((product) => {
    if (!product.variations || product.variations.length === 0) return null;
    return product.variations.find((variation) => variation.quantity > 0);
  }, []);

  const handleAddToCart = useCallback(
    (product) => {
      if (product.totalQuantity <= 0) {
        alert("This product is out of stock!");
        return;
      }

      const nextExpiringProduct = getNextExpiringProduct(product);
      if (!nextExpiringProduct) {
        alert("No available stock!");
        return;
      }

      setCart((prevCart) => {
        const existingItem = prevCart.find(
          (item) => item.name === product.name && item.brand === product.brand
        );

        if (existingItem) {
          const totalQuantity = product.totalQuantity;
          if (existingItem.quantity >= totalQuantity) {
            alert("Cannot add more than available stock!");
            return prevCart;
          }
          return prevCart.map((item) =>
            item.name === product.name && item.brand === product.brand
              ? { ...item, quantity: item.quantity + 1 }
              : item
          );
        }

        return [
          ...prevCart,
          {
            ...nextExpiringProduct,
            quantity: 1,
            originalProduct: product,
          },
        ];
      });
    },
    [getNextExpiringProduct]
  );

  const handleUpdateQuantity = useCallback((itemId, change) => {
    setCart((prevCart) => {
      return prevCart.map((item) => {
        if (item.id === itemId) {
          const originalProduct = item.originalProduct;
          const newQuantity = item.quantity + change;
          if (newQuantity <= 0) {
            return { ...item, quantity: 0 };
          }
          if (newQuantity > originalProduct.totalQuantity) {
            alert("Cannot add more than available stock!");
            return item;
          }
          return { ...item, quantity: newQuantity };
        }
        return item;
      });
    });
  }, []);

  const handleRemoveFromCart = useCallback((productId, skipConfirm) => {
    // skipConfirm is always true from the dialog
    setCart((prevCart) => prevCart.filter((item) => item.id !== productId));
  }, []);

  const handleCheckout = async (skipConfirm) => {
    // skipConfirm is always true from the dialog
    try {
      // Create sales records
      const sales = cart.map((item) => ({
        product: item.id,
        quantity: item.quantity,
        amount_paid: item.selling_price * item.quantity,
      }));

      await Promise.all(sales.map((sale) => api.post("sales/", sale)));

      // Update product quantities
      for (const item of cart) {
        const originalProduct = products.find(
          (p) => p.name === item.name && p.brand === item.brand
        );

        if (originalProduct) {
          let remainingQuantity = item.quantity;
          for (const variation of originalProduct.variations) {
            if (remainingQuantity <= 0) break;

            if (variation.quantity > 0) {
              const quantityToDeduct = Math.min(
                variation.quantity,
                remainingQuantity
              );
              await api.put(`products/${variation.id}/`, {
                ...variation,
                quantity: variation.quantity - quantityToDeduct,
              });
              remainingQuantity -= quantityToDeduct;
            }
          }
        }
      }

      setCart([]);
      fetchProducts(); // Refresh products after checkout

      // Trigger refresh events
      triggerRefresh(REFRESH_EVENTS.ALL); // Refresh everything after checkout
    } catch (error) {
      console.error("Error during checkout:", error);
      // Optionally, you can set an error state here for the UI
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "-";
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (error) {
      return "-";
    }
  };

  // Add this function for direct quantity input
  const handleSetQuantity = useCallback((itemId, value) => {
    // If the input is empty, do not update or remove the item
    if (value === "") return;
    setCart((prevCart) => {
      if (value <= 0 || isNaN(value)) {
        // Remove item if quantity is 0 or less
        return prevCart.filter((item) => item.id !== itemId);
      }
      return prevCart.map((item) => {
        if (item.id === itemId) {
          const originalProduct = item.originalProduct;
          let newQuantity = value;
          if (newQuantity > originalProduct.totalQuantity) {
            alert("Cannot add more than available stock!");
            newQuantity = originalProduct.totalQuantity;
          }
          return { ...item, quantity: newQuantity };
        }
        return item;
      });
    });
  }, []);

  const value = {
    products,
    cart,
    loading,
    error,
    searchTerm,
    setSearchTerm,
    formatPrice,
    formatDate,
    getStockLevel,
    handleAddToCart,
    handleUpdateQuantity,
    handleRemoveFromCart,
    handleCheckout,
    handleSetQuantity,
    fetchProducts,
  };

  return <POSContext.Provider value={value}>{children}</POSContext.Provider>;
};

export const usePOS = () => {
  const context = useContext(POSContext);
  if (!context) {
    throw new Error("usePOS must be used within a POSProvider");
  }
  return context;
};
