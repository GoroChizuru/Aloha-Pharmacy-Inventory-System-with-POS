import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import { api } from "../api";
import { triggerRefresh, REFRESH_EVENTS } from "../utils/refreshEvents";

const InventoryContext = createContext();

export const InventoryProvider = ({ children }) => {
  const [inventory, setInventory] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [expandedGroups, setExpandedGroups] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [formData, setFormData] = useState({
    product: "",
    reorder_level: 10,
    unit_price: "",
    date_of_receive: "",
  });

  const groupInventory = (items) => {
    const grouped = {};
    const processedProducts = new Set();

    items.forEach((item) => {
      const key = `${item.product_name}_${item.product_brand}`;

      // Initialize the group if it doesn't exist
      if (!grouped[key]) {
        grouped[key] = {
          id: item.product.id,
          name: item.product_name,
          brand: item.product_brand,
          totalStock: 0,
          minPrice: Infinity,
          maxPrice: -Infinity,
          variations: [],
          reorder_level: item.reorder_level || 10,
          status: "In Stock",
        };
      }

      // Only add variant if we haven't processed this product ID yet
      if (!processedProducts.has(item.product.id)) {
        // Add this variant to variations
        const variant = {
          ...item,
          quantity: item.product.quantity || 0,
        };
        grouped[key].variations.push(variant);

        // Add this variant's quantity to total stock
        grouped[key].totalStock += item.product.quantity || 0;

        // Update min/max prices
        grouped[key].minPrice = Math.min(
          grouped[key].minPrice,
          parseFloat(item.unit_price || 0)
        );
        grouped[key].maxPrice = Math.max(
          grouped[key].maxPrice,
          parseFloat(item.unit_price || 0)
        );

        // Mark this product as processed
        processedProducts.add(item.product.id);
      }

      // Update status based on total stock and reorder level
      if (grouped[key].totalStock <= 0) {
        grouped[key].status = "Out of Stock";
      } else if (grouped[key].totalStock <= grouped[key].reorder_level) {
        grouped[key].status = "Low Stock";
      } else {
        grouped[key].status = "In Stock";
      }
    });

    return Object.values(grouped);
  };

  const handleProductSelect = (product) => {
    setSelectedProduct(product);
    setFormData({
      product: product.id,
      reorder_level: product.reorder_level || 10,
      unit_price: product.minPrice,
      date_of_receive: new Date().toISOString().split("T")[0],
    });
  };

  const toggleVariants = (groupIndex) => {
    setExpandedGroups((prev) =>
      prev.includes(groupIndex)
        ? prev.filter((index) => index !== groupIndex)
        : [...prev, groupIndex]
    );
  };

  const fetchInventory = useCallback(async () => {
    try {
      setLoading(true);
      const response = await api.get("inventory/");
      if (response.data) {
        const inventoryWithDetails = response.data.map((item) => ({
          ...item,
          product_name:
            item.product_name || item.product?.name || "Unknown Product",
          product_brand:
            item.product_brand || item.product?.brand || "Unknown Brand",
          expiration_date:
            item.product_expiration || item.product?.expiration_date,
          quantity: item.quantity || 0,
          unit_price: item.unit_price || 0,
        }));
        setInventory(groupInventory(inventoryWithDetails));
        setError(null);
      }
    } catch (err) {
      console.error("Failed to fetch inventory data:", err);
      setError("Failed to fetch inventory data. Please try again later.");
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchProducts = useCallback(async () => {
    try {
      const response = await api.get("products/");
      setProducts(response.data);
    } catch (err) {
      console.error("Failed to fetch products:", err);
    }
  }, []);

  // Initial data fetch
  useEffect(() => {
    fetchInventory();
    fetchProducts();
  }, [fetchInventory, fetchProducts]);

  // Listen for refresh events
  useEffect(() => {
    const handleRefresh = () => {
      fetchInventory();
      fetchProducts();
    };

    window.addEventListener(REFRESH_EVENTS.ALL, handleRefresh);
    return () => {
      window.removeEventListener(REFRESH_EVENTS.ALL, handleRefresh);
    };
  }, [fetchInventory, fetchProducts]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e, skipConfirm) => {
    if (e) e.preventDefault();
    try {
      const payload = {
        product_id: parseInt(formData.product),
        reorder_level: parseInt(formData.reorder_level),
        unit_price: parseFloat(formData.unit_price),
        date_of_receive: formData.date_of_receive,
      };

      if (editingItem) {
        await api.put(`inventory/${editingItem.id}/`, payload);
      } else {
        await api.post("inventory/", payload);
      }
      setShowForm(false);
      setFormData({
        product: "",
        reorder_level: 10,
        unit_price: "",
        date_of_receive: "",
      });
      setSelectedProduct(null);
      fetchInventory();
      // Trigger refresh events
      triggerRefresh(REFRESH_EVENTS.INVENTORY);
      triggerRefresh(REFRESH_EVENTS.PRODUCTS);
    } catch (error) {
      console.error("Error saving inventory item:", error);
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setSelectedProduct(item);
    setFormData({
      product: item.product.id,
      reorder_level: item.reorder_level,
      unit_price: item.unit_price,
      date_of_receive: item.date_of_receive,
    });
    setShowForm(true);
  };

  const handleDelete = async (itemId) => {
    try {
      await api.delete(`inventory/${itemId}/`);
      fetchInventory();
      // Trigger refresh events
      triggerRefresh(REFRESH_EVENTS.INVENTORY);
      triggerRefresh(REFRESH_EVENTS.PRODUCTS);
    } catch (error) {
      console.error("Error deleting inventory item:", error);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return "-";
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (error) {
      return "-";
    }
  };

  const value = {
    inventory,
    products,
    loading,
    error,
    showForm,
    editingItem,
    formData,
    expandedGroups,
    selectedProduct,
    setShowForm,
    setFormData,
    handleInputChange,
    handleSubmit,
    handleEdit,
    handleDelete,
    toggleVariants,
    handleProductSelect,
    formatDate,
    fetchInventory,
    fetchProducts,
  };

  return (
    <InventoryContext.Provider value={value}>
      {children}
    </InventoryContext.Provider>
  );
};

export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error("useInventory must be used within an InventoryProvider");
  }
  return context;
};
