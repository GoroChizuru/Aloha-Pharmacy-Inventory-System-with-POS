import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import { api } from "../api";
import { triggerRefresh, REFRESH_EVENTS } from "../utils/refreshEvents";

const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [editingProduct, setEditingProduct] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState([]);
  const [formData, setFormData] = useState({
    name: "",
    brand: "",
    quantity: "",
    expiration_date: "",
    selling_price: "",
    category: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const groupProducts = (products, inventoryItems) => {
    const grouped = {};
    const inventoryMap = {};

    // Create inventory map for quick lookup
    inventoryItems.forEach((item) => {
      const key = item.product.id;
      if (!inventoryMap[key]) {
        inventoryMap[key] = [];
      }
      inventoryMap[key].push(item);
    });

    products.forEach((product) => {
      const key = `${product.name}_${product.brand}`;

      if (!grouped[key]) {
        grouped[key] = {
          name: product.name,
          brand: product.brand,
          category: product.category,
          totalQuantity: 0,
          minPrice: Infinity,
          maxPrice: -Infinity,
          variations: [],
        };
      }

      // Get inventory items for this product
      const productInventory = inventoryMap[product.id] || [];
      const productWithInventory = {
        ...product,
        inventory: productInventory,
        // Use the latest expiration date from inventory if available
        expiration_date:
          productInventory.length > 0
            ? productInventory.reduce((latest, item) => {
                try {
                  const itemDate = new Date(item.expiration_date);
                  return isNaN(itemDate.getTime())
                    ? latest
                    : latest > itemDate
                    ? latest
                    : itemDate;
                } catch (error) {
                  return latest;
                }
              }, new Date(0))
            : product.expiration_date,
      };

      grouped[key].variations.push(productWithInventory);
      grouped[key].totalQuantity += parseInt(product.quantity || 0);
      grouped[key].minPrice = Math.min(
        grouped[key].minPrice,
        parseFloat(product.selling_price || 0)
      );
      grouped[key].maxPrice = Math.max(
        grouped[key].maxPrice,
        parseFloat(product.selling_price || 0)
      );
    });

    return Object.values(grouped);
  };

  const fetchInventory = async () => {
    try {
      const response = await api.get("inventory/");
      setInventory(response.data);
    } catch (error) {
      console.error("Error fetching inventory:", error);
    }
  };

  const fetchProducts = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.get("products/");
      if (response.data) {
        // Ensure we have inventory data before grouping
        if (inventory.length === 0) {
          await fetchInventory();
        }
        const groupedProducts = groupProducts(response.data, inventory);
        setProducts(groupedProducts);
      }
    } catch (error) {
      console.error("Error fetching products:", error);
      setError("Failed to fetch products. Please try again later.");
      setProducts([]); // Clear products on error
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  // Refresh products when inventory changes
  useEffect(() => {
    if (inventory.length > 0) {
      const loadProducts = async () => {
        try {
          const response = await api.get("products/");
          if (response.data) {
            const groupedProducts = groupProducts(response.data, inventory);
            setProducts(groupedProducts);
          }
        } catch (error) {
          console.error("Error refreshing products:", error);
        }
      };
      loadProducts();
    }
  }, [inventory]);

  const handleAddProduct = () => {
    setEditingProduct(null);
    setFormData({
      name: "",
      brand: "",
      quantity: "",
      expiration_date: "",
      selling_price: "",
      category: "",
    });
    setIsModalOpen(true);
  };

  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      brand: product.brand,
      quantity: product.quantity,
      expiration_date: product.expiration_date,
      selling_price: product.selling_price,
      category: product.category,
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e, skipConfirm) => {
    if (e) e.preventDefault();
    try {
      const payload = {
        ...formData,
        quantity: parseInt(formData.quantity),
        selling_price: parseFloat(formData.selling_price),
      };

      let response;
      if (editingProduct) {
        response = await api.put(`products/${editingProduct.id}/`, payload);
      } else {
        response = await api.post("products/", payload);
        if (response.data.inventory) {
          setInventory((prevInventory) => [
            ...prevInventory,
            response.data.inventory,
          ]);
        }
      }
      setIsModalOpen(false);
      await fetchProducts(); // Wait for products to be fetched
      // Trigger refresh events
      triggerRefresh(REFRESH_EVENTS.ALL);
    } catch (error) {
      console.error("Error saving product:", error);
      setError("Failed to save product. Please try again.");
    }
  };

  const handleDeleteProduct = async (productId) => {
    try {
      await api.delete(`products/${productId}/`);
      await fetchProducts(); // Wait for products to be fetched
      // Trigger refresh events
      triggerRefresh(REFRESH_EVENTS.ALL);
    } catch (error) {
      console.error("Error deleting product:", error);
    }
  };

  const handleAddVariant = (group) => {
    setEditingProduct(null);
    setFormData({
      name: group.name,
      brand: group.brand,
      quantity: "",
      expiration_date: "",
      selling_price: group.minPrice,
      category: group.category || "",
    });
    setIsModalOpen(true);
  };

  const toggleVariants = (groupIndex) => {
    setExpandedGroups((prev) =>
      prev.includes(groupIndex)
        ? prev.filter((index) => index !== groupIndex)
        : [...prev, groupIndex]
    );
  };

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        return "Invalid Date";
      }
      return date.toLocaleDateString();
    } catch (error) {
      return "Invalid Date";
    }
  };

  const value = {
    products,
    editingProduct,
    isModalOpen,
    formData,
    expandedGroups,
    setFormData,
    setIsModalOpen,
    handleAddProduct,
    handleEditProduct,
    handleSubmit,
    handleDeleteProduct,
    handleAddVariant,
    toggleVariants,
    formatDate,
    loading,
    error,
  };

  return (
    <ProductContext.Provider value={value}>{children}</ProductContext.Provider>
  );
};

export const useProduct = () => {
  const context = useContext(ProductContext);
  if (!context) {
    throw new Error("useProduct must be used within a ProductProvider");
  }
  return context;
};
