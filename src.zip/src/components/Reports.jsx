import React, { useRef, useEffect, useState } from "react";
import html2pdf from "html2pdf.js";
import { useReports } from "../hooks/useReports";
import { onRefresh, REFRESH_EVENTS } from "../utils/refreshEvents";

const Reports = () => {
  const {
    salesData,
    inventoryData,
    dateRange,
    setDateRange,
    totalSales,
    lowStockItems,
    error,
    calculateTotalSales,
    calculateLowStockItems,
    formatDate,
    formatPrice,
    fetchData,
  } = useReports();

  const reportRef = useRef();
  const [showDateWarning, setShowDateWarning] = useState(false);

  useEffect(() => {
    const cleanup = onRefresh(REFRESH_EVENTS.ALL, () => {
      fetchData();
    });

    return cleanup;
  }, [fetchData]);

  const handleGeneratePDF = () => {
    if (!dateRange.start || !dateRange.end) {
      setShowDateWarning(true);
      return;
    }
    setShowDateWarning(false);
    // Only include the sales summary and sales table in the PDF
    const pdfContent = document.createElement("div");
    // Clone the summary cards
    const summaryCards = reportRef.current.querySelector(".grid");
    if (summaryCards) pdfContent.appendChild(summaryCards.cloneNode(true));
    // Clone the sales table
    const salesTable = reportRef.current.querySelector(
      ".bg-white.rounded-lg.shadow.border.border-green-100.mb-6"
    );
    if (salesTable) pdfContent.appendChild(salesTable.cloneNode(true));
    html2pdf(pdfContent, {
      margin: 0.2,
      filename: `AlohaPharmacy-Report-${dateRange.start || "all"}-${
        dateRange.end || "all"
      }.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 1.5, scrollX: 0, scrollY: 0, windowWidth: 1200 },
      jsPDF: { unit: "in", format: "a4", orientation: "landscape" },
    });
  };

  if (error) {
    return (
      <div className="container mx-auto p-4">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-6 text-green-700">Reports</h1>
      {showDateWarning && (
        <div className="mb-4 bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-2 rounded">
          Please select both a start and end date to generate a report.
        </div>
      )}
      <button
        onClick={handleGeneratePDF}
        className="mb-4 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
      >
        Generate Report
      </button>

      <div ref={reportRef}>
        {/* Date Range Filter */}
        <div className="mb-6 flex gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Start Date
            </label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) =>
                setDateRange({ ...dateRange, start: e.target.value })
              }
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              End Date
            </label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) =>
                setDateRange({ ...dateRange, end: e.target.value })
              }
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
            />
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white p-6 rounded-lg shadow border border-green-100">
            <h3 className="text-lg font-semibold text-gray-900">Total Sales</h3>
            <p className="mt-2 text-3xl font-bold text-green-600">
              ₱{formatPrice(calculateTotalSales())}
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow border border-green-100">
            <h3 className="text-lg font-semibold text-gray-900">
              Number of Sales
            </h3>
            <p className="mt-2 text-3xl font-bold text-green-600">
              {salesData.length}
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow border border-green-100">
            <h3 className="text-lg font-semibold text-gray-900">
              Low Stock Items
            </h3>
            <p className="mt-2 text-3xl font-bold text-green-600">
              {calculateLowStockItems()}
            </p>
          </div>
        </div>

        {/* Sales Table */}
        <div className="bg-white rounded-lg shadow border border-green-100 mb-6">
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              Sales History
            </h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr className="bg-green-50">
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Product
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Brand
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Quantity
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Unit Price
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Total
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {salesData.map((sale) => (
                    <tr key={sale.id} className="hover:bg-green-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatDate(sale.date_of_sale)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sale.product_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sale.product_brand}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {sale.quantity || 0}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₱{formatPrice(sale.amount_paid / sale.quantity)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₱{formatPrice(sale.total)}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-green-50 font-semibold">
                    <td
                      colSpan="5"
                      className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right"
                    >
                      Total Sales:
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ₱{formatPrice(calculateTotalSales())}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Inventory Status */}
        <div className="bg-white rounded-lg shadow border border-green-100">
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              Inventory Status
            </h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr className="bg-green-50">
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Product
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Brand
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Quantity
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {inventoryData.map((item) => (
                    <tr key={item.id} className="hover:bg-green-50">
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {item.name || "Unknown Product"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {item.brand || "Generic"}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {item.totalStock || 0}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            item.status === "Low Stock"
                              ? "bg-red-100 text-red-800"
                              : item.status === "Out of Stock"
                              ? "bg-gray-100 text-gray-800"
                              : "bg-green-100 text-green-800"
                          }`}
                        >
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
