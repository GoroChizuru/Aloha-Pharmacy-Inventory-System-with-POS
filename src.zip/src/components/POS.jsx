import React, { useState, useEffect } from "react";
import { usePOS } from "../context/POSContext";
import ConfirmDialog from "./ConfirmDialog";
import { onRefresh, REFRESH_EVENTS } from "../utils/refreshEvents";

const POS = () => {
  const {
    products,
    cart,
    loading,
    error,
    searchTerm,
    setSearchTerm,
    formatPrice,
    formatDate,
    getStockLevel,
    handleAddToCart,
    handleUpdateQuantity,
    handleRemoveFromCart,
    handleCheckout,
    handleSetQuantity,
    fetchProducts,
  } = usePOS();

  const [searchCategory, setSearchCategory] = useState("");

  // Add effect to listen for refresh events
  useEffect(() => {
    const cleanup = onRefresh(REFRESH_EVENTS.ALL, () => {
      fetchProducts(); // Refresh products when any change occurs
    });

    return cleanup; // Cleanup listener on unmount
  }, [fetchProducts]);

  // State for confirmation dialog
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmMessage, setConfirmMessage] = useState("");
  const [pendingAction, setPendingAction] = useState(null);

  // Local state for cart input values
  const [cartInputValues, setCartInputValues] = useState({});

  // Update local input value on change
  const handleCartInputChange = (itemId, value) => {
    setCartInputValues((prev) => ({ ...prev, [itemId]: value }));
  };

  // On blur or Enter, update the cart quantity
  const handleCartInputCommit = (itemId, value) => {
    if (value === "") return; // Don't update if still empty
    handleSetQuantity(itemId, Number(value));
  };

  // Wrappers for actions that need confirmation
  const requestRemoveFromCart = (itemId) => {
    setConfirmMessage(
      "Are you sure you want to remove this item from the cart?"
    );
    setPendingAction(() => () => handleRemoveFromCart(itemId, true));
    setConfirmOpen(true);
  };

  const requestCheckout = () => {
    setConfirmMessage("Are you sure you want to proceed with checkout?");
    setPendingAction(() => () => handleCheckout(true));
    setConfirmOpen(true);
  };

  // ConfirmDialog handlers
  const handleConfirm = () => {
    if (pendingAction) pendingAction();
    setConfirmOpen(false);
    setPendingAction(null);
  };
  const handleCancel = () => {
    setConfirmOpen(false);
    setPendingAction(null);
  };

  if (loading) return <div className="text-center p-4">Loading...</div>;
  if (error) return <div className="text-red-500 text-center p-4">{error}</div>;

  // Enhanced filtering for products
  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      !searchCategory ||
      product.category.toLowerCase() === searchCategory.toLowerCase();
    const hasStock = getStockLevel(product) > 0;
    return matchesSearch && matchesCategory && hasStock;
  });

  // Get unique categories for filter dropdown
  const categories = [...new Set(products.map((product) => product.category))];

  const total = cart.reduce(
    (sum, item) => sum + item.selling_price * item.quantity,
    0
  );

  return (
    <div className="container mx-auto p-4">
      <ConfirmDialog
        open={confirmOpen}
        message={confirmMessage}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {/* Enhanced Search Section */}
          <div className="mb-6 flex gap-4">
            <div className="flex-1">
              <input
                type="text"
                placeholder="Search products by name or brand..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
            </div>
            <div className="w-48">
              <select
                value={searchCategory}
                onChange={(e) => setSearchCategory(e.target.value)}
                className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                <option value="">All Categories</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProducts.map((product) => (
              <div
                key={product.name + product.brand}
                className="bg-white rounded-lg shadow-md p-4 border border-gray-200"
              >
                <h3 className="text-lg font-semibold text-gray-800">
                  {product.name}
                </h3>
                <p className="text-gray-600">Brand: {product.brand}</p>
                <p className="text-gray-600">
                  Price: ₱{formatPrice(product.selling_price)}
                </p>
                <p className="text-gray-600">Stock: {getStockLevel(product)}</p>
                <p className="text-gray-600 text-sm">
                  Next Expiry:{" "}
                  {formatDate(product.variations[0]?.expiration_date)}
                </p>
                <button
                  onClick={() => handleAddToCart(product)}
                  className="mt-2 w-full bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md"
                  disabled={getStockLevel(product) === 0}
                >
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-4 border border-gray-200">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Cart</h2>
            {cart.length === 0 ? (
              <p className="text-gray-600">Your cart is empty</p>
            ) : (
              <>
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.id}
                      className="flex justify-between items-center"
                    >
                      <div>
                        <h3 className="font-medium text-gray-800">
                          {item.name}
                        </h3>
                        <p className="text-gray-600">
                          ₱{formatPrice(item.selling_price)} x {item.quantity}
                        </p>
                        <p className="text-gray-500 text-sm">
                          Expires: {formatDate(item.expiration_date)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min={1}
                          max={item.originalProduct?.totalQuantity || 1}
                          value={
                            cartInputValues[item.id] !== undefined
                              ? cartInputValues[item.id]
                              : item.quantity
                          }
                          onChange={(e) =>
                            handleCartInputChange(item.id, e.target.value)
                          }
                          onBlur={(e) =>
                            handleCartInputCommit(item.id, e.target.value)
                          }
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              handleCartInputCommit(item.id, e.target.value);
                              e.target.blur();
                            }
                          }}
                          className="w-16 p-1 border rounded text-center"
                        />
                        <button
                          onClick={() => requestRemoveFromCart(item.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 pt-4 border-t">
                  <div className="flex justify-between items-center mb-4">
                    <span className="font-bold text-gray-800">Total:</span>
                    <span className="font-bold text-gray-800">
                      ₱{formatPrice(total)}
                    </span>
                  </div>
                  <button
                    onClick={requestCheckout}
                    className="w-full bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md"
                  >
                    Checkout
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default POS;
