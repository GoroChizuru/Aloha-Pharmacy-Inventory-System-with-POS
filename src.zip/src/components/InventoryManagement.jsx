import React, { useState, useEffect, useRef } from "react";
import { useInventory } from "../context/InventoryContext";
import ConfirmDialog from "./ConfirmDialog";
import { useLocation } from "react-router-dom";
import { onRefresh, REFRESH_EVENTS } from "../utils/refreshEvents";

const InventoryManagement = () => {
  const {
    inventory,
    products,
    showForm,
    handleEdit,
    handleDelete,
    setShowForm,
    formData,
    handleSubmit,
    handleInputChange,
    expandedGroups,
    toggleVariants,
    formatDate,
    handleProductSelect,
    selectedProduct,
    setFormData,
    fetchInventory,
  } = useInventory();

  const location = useLocation();
  const highlightId = location.state?.highlightId;
  const highlightType = location.state?.highlightType;
  const highlightGroupKey = location.state?.highlightGroupKey;
  const rowRefs = useRef({});

  const [searchTerm, setSearchTerm] = useState("");
  const [searchStatus, setSearchStatus] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Filter inventory based on search term and status
  const filteredInventory = inventory.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.brand.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = !searchStatus || item.status === searchStatus;
    return matchesSearch && matchesStatus;
  });

  // Calculate pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredInventory.slice(
    indexOfFirstItem,
    indexOfLastItem
  );
  const totalPages = Math.ceil(filteredInventory.length / itemsPerPage);

  // Handle page change
  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  // Reset to first page when search or filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, searchStatus]);

  useEffect(() => {
    if (highlightId && rowRefs.current[highlightId]) {
      rowRefs.current[highlightId].scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }
  }, [highlightId]);

  // Add effect to listen for refresh events
  useEffect(() => {
    const cleanup = onRefresh(REFRESH_EVENTS.ALL, () => {
      fetchInventory(); // Refresh inventory when any change occurs
    });

    return cleanup; // Cleanup listener on unmount
  }, [fetchInventory]);

  // State for confirmation dialog
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirmMessage, setConfirmMessage] = useState("");
  const [pendingAction, setPendingAction] = useState(null);

  // Wrappers for actions that need confirmation
  const requestDelete = (itemId) => {
    setConfirmMessage("Are you sure you want to delete this inventory item?");
    setPendingAction(() => () => handleDelete(itemId, true));
    setConfirmOpen(true);
  };

  const requestSubmit = (e) => {
    e.preventDefault();
    const action = formData.id ? "update" : "add";
    setConfirmMessage(
      `Are you sure you want to ${action} this inventory item?`
    );
    setPendingAction(() => () => handleSubmit(e, true));
    setConfirmOpen(true);
  };

  // ConfirmDialog handlers
  const handleConfirm = () => {
    if (pendingAction) pendingAction();
    setConfirmOpen(false);
    setPendingAction(null);
  };
  const handleCancel = () => {
    setConfirmOpen(false);
    setPendingAction(null);
  };

  return (
    <div className="container mx-auto p-4">
      <ConfirmDialog
        open={confirmOpen}
        message={confirmMessage}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-primary-600">
          Inventory Management
        </h1>
        <button
          onClick={() => {
            // Prefill with current stock level if a product is selected
            if (selectedProduct) {
              setFormData({
                ...formData,
                reorder_level: selectedProduct.totalStock || 0,
              });
            }
            setShowForm(true);
          }}
          className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md"
        >
          Set Stock Level
        </button>
      </div>

      {/* Search and Filter Section */}
      <div className="mb-6 flex gap-4">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search inventory by name or brand..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
          />
        </div>
        <div className="w-48">
          <select
            value={searchStatus}
            onChange={(e) => setSearchStatus(e.target.value)}
            className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <option value="">All Status</option>
            <option value="In Stock">In Stock</option>
            <option value="Low Stock">Low Stock</option>
            <option value="Out of Stock">Out of Stock</option>
          </select>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 bg-white shadow-md rounded-lg">
          <thead className="bg-primary-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Select
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Product
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Brand
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Unit Price
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Expiration Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Quantity
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {currentItems.map((group, groupIndex) => (
              <React.Fragment key={groupIndex}>
                <tr
                  className={`group hover:bg-green-50 ${
                    highlightGroupKey &&
                    group.name === highlightGroupKey.name &&
                    group.brand === highlightGroupKey.brand &&
                    group.category === highlightGroupKey.category &&
                    highlightType === "low_stock"
                      ? "bg-yellow-200"
                      : ""
                  }`}
                >
                  <td className="px-6 py-4">
                    <input
                      type="checkbox"
                      checked={expandedGroups.includes(groupIndex)}
                      onChange={() => {
                        toggleVariants(groupIndex);
                        handleProductSelect(group);
                      }}
                      className="h-4 w-4 text-primary-600 rounded border-gray-300 focus:ring-primary-500"
                    />
                  </td>
                  <td className="px-6 py-4">{group.name}</td>
                  <td className="px-6 py-4">{group.brand}</td>
                  <td className="px-6 py-4">{group.category}</td>
                  <td className="px-6 py-4">
                    ₱{group.minPrice.toFixed(2)}
                    {group.minPrice !== group.maxPrice &&
                      ` - ₱${group.maxPrice.toFixed(2)}`}
                  </td>
                  <td className="px-6 py-4">-</td>
                  <td className="px-6 py-4">{group.totalStock}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        group.status === "Out of Stock"
                          ? "bg-red-100 text-red-800"
                          : group.status === "Low Stock"
                          ? "bg-yellow-100 text-yellow-800"
                          : "bg-green-100 text-green-800"
                      }`}
                    >
                      {group.status}
                    </span>
                  </td>
                </tr>
                {expandedGroups.includes(groupIndex) &&
                  group.variations.map((item) => (
                    <tr
                      key={item.id}
                      ref={(el) => (rowRefs.current[item.id] = el)}
                      className={`bg-green-50/50 border-t border-green-100 ${
                        highlightId === item.id && highlightType === "low_stock"
                          ? "bg-yellow-200"
                          : ""
                      }`}
                    >
                      <td className="px-6 py-2"></td>
                      <td className="px-6 py-2 pl-12">
                        <span className="text-gray-400">
                          {item.product?.name}
                        </span>
                      </td>
                      <td className="px-6 py-2">{item.product?.brand}</td>
                      <td className="px-6 py-2">{item.product?.category}</td>
                      <td className="px-6 py-2">
                        ₱{parseFloat(item.unit_price).toFixed(2)}
                      </td>
                      <td className="px-6 py-2">
                        {formatDate(
                          item.expiration_date || item.product?.expiration_date
                        )}
                      </td>
                      <td className="px-6 py-2">{item.product?.quantity}</td>
                      <td className="px-6 py-2"></td>
                      <td className="px-6 py-2 text-right space-x-2">
                        {/* Removed Edit and Delete buttons */}
                      </td>
                    </tr>
                  ))}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      <div className="mt-4 flex justify-between items-center">
        <div className="text-sm text-gray-700">
          Showing {indexOfFirstItem + 1} to{" "}
          {Math.min(indexOfLastItem, filteredInventory.length)} of{" "}
          {filteredInventory.length} items
        </div>
        <div className="flex gap-2">
          <button
            onClick={handlePrevPage}
            disabled={currentPage === 1}
            className={`px-4 py-2 rounded-md ${
              currentPage === 1
                ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                : "bg-primary-600 text-white hover:bg-primary-700"
            }`}
          >
            Previous
          </button>
          <button
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
            className={`px-4 py-2 rounded-md ${
              currentPage === totalPages
                ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                : "bg-primary-600 text-white hover:bg-primary-700"
            }`}
          >
            Next
          </button>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">
                Set Stock Level
              </h3>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                ×
              </button>
            </div>
            <form onSubmit={requestSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Product
                </label>
                <input
                  type="text"
                  value={
                    selectedProduct
                      ? `${selectedProduct.name} - ${selectedProduct.brand}`
                      : ""
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  disabled
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Reorder Level
                </label>
                <input
                  type="number"
                  name="reorder_level"
                  value={formData.reorder_level}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  required
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 rounded-md"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default InventoryManagement;
